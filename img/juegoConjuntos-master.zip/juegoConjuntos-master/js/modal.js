

document.getElementById('openModalBtn').addEventListener('click', function() {
    $('#optionsModal').modal('show');
});

